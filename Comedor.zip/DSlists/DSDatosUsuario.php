
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>CONFIRMAR</title>
	<link rel="stylesheet" type="text/css" href="../ext/resources/css/ext-all.css" />
	<style type="text/css">
		<!--
		.divcentro {position: absolute;top: 50%;left: 50%;
			}
		-->
		.name{	
		font-size:10px !important;
		color:#000022;	
	}
		</style>
    <!-- GC -->
 	<!-- LIBS -->
 	<script type="text/javascript" src="../ext/adapter/ext/ext-base.js"></script>
 	<!-- ENDLIBS -->

    <script type="text/javascript" src="../ext/ext-all.js"></script>	
    
     <script src="../DSforms/DSDatosUsuario.js" type='text/javascript'></script>
	 
	<!--<script src="../DSforms/DSNuevoReclamo.js" type='text/javascript'></script>
	<script src="../DSforms/DSNuevoReprogramar.js" type='text/javascript'></script> -->
	
	<style type="text/css">
	.ColorAzul table{
			background-color: #deecfd;
			color: #15428b;
			font: bold 11px;
	}
	.ColorRojo table{
			background-color: #fddeec;
			color: #15428b;
			font: bold 11px;
	}
	.ColorVerde table{
			background-color: #ecfdde;
			color: #15428b;
			font: bold 11px;
	}
	.x-grid3-row-alt {
		background-color: #cccccc !important;  
	}
	
	
	</style>
	</head>
	<body> 		
	</body>
</html>